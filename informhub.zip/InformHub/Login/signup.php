<?php
/**
 * Informatika Hub - Signup Page
 * 
 * This file combines the signup form and registration processing functionality.
 */

session_start();
include '../database/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validate inputs
    if ($password !== $confirm_password) {
        $error_message = 'Password and confirm password do not match';
    } else {
        // Sanitize inputs to prevent SQL injection
        $username = mysqli_real_escape_string($conn, $username);
        $email = mysqli_real_escape_string($conn, $email);
        $password = mysqli_real_escape_string($conn, $password);

        // Check if email already exists
        $sql_check = "SELECT * FROM users WHERE email = '$email'";
        $result_check = mysqli_query($conn, $sql_check);

        if (mysqli_num_rows($result_check) > 0) {
            $error_message = 'Email already exists. Please use a different email';
        } else {
            // Check if username already exists
            $check_username = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username'");
            if (mysqli_num_rows($check_username) > 0) {
                $error_message = 'Username already taken';
            } else {
                // Insert new user
                $sql_insert = "INSERT INTO users (username, email, password, role) VALUES ('$username', '$email', '$password', 'user')";
                
                if (mysqli_query($conn, $sql_insert)) {
                    // Registration successful
                    $_SESSION['registration_success'] = true;
                    header("Location: login.php?registered=1");
                    exit();
                } else {
                    // Registration failed
                    $error_message = 'Registration failed: ' . mysqli_error($conn);
                }
            }
        }
    }
}
?><!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register - Informatika Hub</title>
  <link rel="stylesheet" href="assets/style.css">
  <link rel="stylesheet" href="assets/header-footer.css">
  <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
  <!-- Header Start -->
  <header class="header">
    <div class="header-container">
      <div class="logo">
        <a href="../Home/index.php">Informatika<span>Hub</span></a>
      </div>
      <div class="nav-menu">
        <ul>
          <li><a href="../Home/index.php">Home</a></li>
          <li><a href="../Home/index.php#explore">Explore</a></li>
          <li><a href="../Tutorial/course.php">Tutorials</a></li>
          <li><a href="../Home/index.php#contact">Contact</a></li>
        </ul>
      </div>
    </div>
  </header>
  <!-- Header End -->
  
  <div class="wrapper">
    <div class="title">
      Registration Form
    </div>
    <?php if(isset($error_message)): ?>
    <div style="background-color: #f8d7da; color: #721c24; padding: 10px; margin-bottom: 15px; border-radius: 5px; text-align: center;">
      <?php echo $error_message; ?>
    </div>
    <?php endif; ?>
    <?php if(isset($_GET['registered']) && $_GET['registered'] == 1): ?>
    <div style="background-color: #d4edda; color: #155724; padding: 10px; margin-bottom: 15px; border-radius: 5px; text-align: center;">
      Registration successful! You can now login.
    </div>
    <?php endif; ?>
    <form action="signup.php" method="post">
      <div class="field">
        <input type="text" name="username" required>
        <label>Nama Lengkap</label>
      </div>
      <div class="field">
        <input type="text" name="email" required>
        <label>Alamat Email</label>
      </div>
      <div class="field">
        <input type="password" name="password" required>
        <label>Masukan Password</label>
      </div>
      <div class="field">
        <input type="password" name="confirm_password" required>
        <label>Konfirmasi Password</label>
      </div>
      <div class="field">
        <input type="submit" value="Signup">
      </div>
      <div class="signup-link">
        Already have an account? <a href="login.php">Login now</a>
      </div>
    </form>
  </div>

  <!-- Footer Start -->
  <footer class="footer">
    <div class="footer-container">
      <div class="footer-content">
        <div class="footer-section">
          <h2>Informatika<span style="color: #ff3333;">Hub</span></h2>
          <p>Modern Web Learning Platform</p>
        </div>

        <div class="footer-section">
          <h2>Link</h2>
          <p><a href="../Home/index.php">Home</a></p>
          <p><a href="../Home/index.php#explore">Explore</a></p>
          <p><a href="../Tutorial/course.php">Tutorials</a></p>
          <p><a href="../Home/index.php#contact">Contact</a></p>
        </div>

        <div class="footer-section">
          <h2>Popular Topics</h2>
          <p><a href="../Tutorial/course.php?topic=html">HTML</a></p>
          <p><a href="../Tutorial/course.php?topic=css">CSS</a></p>
          <p><a href="../Tutorial/course.php?topic=javascript">JavaScript</a></p>
          <p><a href="../Tutorial/course.php?topic=react">React</a></p>
          <p><a href="../Tutorial/course.php?topic=blockchain">Blockchain</a></p>
        </div>

        <div class="footer-section">
          <h2>Contacts</h2>
          <p>+62 123 456 789</p>
          <p><a href="mailto:info@informatikahub.com">info@informatikahub.com</a></p>
          <p>Jl. Pendidikan No. 123</p>
          <p>Jakarta, Indonesia</p>
        </div>
      </div>

      <div class="footer-bottom">
        <div class="footer-social">
          <a href="#"><i class="fab fa-facebook-f"></i></a>
          <a href="#"><i class="fab fa-twitter"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
        </div>
        <p>&copy; 2025 <a href="../Home/index.php">Informatika Hub</a>. All Rights Reserved</p>
      </div>
    </div>
  </footer>
  <!-- Footer End -->
</body>
</html>
?>
