<?php
/**
 * Informatika Hub - Login Page
 * 
 * This file combines the login form and login processing functionality.
 */

session_start();
include '../database/db.php';

// Handle login form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Sanitize inputs to prevent SQL injection
    $email = mysqli_real_escape_string($conn, $email);
    $password = mysqli_real_escape_string($conn, $password);

    // Check if email exists
    $sql_email = "SELECT * FROM users WHERE email = '$email'";
    $result_email = mysqli_query($conn, $sql_email);

    if (mysqli_num_rows($result_email) == 1) {
        // Email found, check password
        $user = mysqli_fetch_assoc($result_email);

        if ($user['password'] === $password) {
            // Password matches → login successful
            $_SESSION['email'] = $email;
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['login_success'] = true; // Flag untuk menandai login berhasil
            
            // Simpan session sebelum redirect
            session_write_close();
            
            // Redirect to home page dengan parameter untuk menampilkan pesan selamat datang
            header("Location: ../Home/index.php?login_success=1");
            exit();
        } else {
            // Wrong password
            $error_message = "Login failed: Wrong password";
        }
    } else {
        // Email not found
        $error_message = "Login failed: Email not found";
    }
}
?><!DOCTYPE html>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Login - Informatika Hub</title>
      <link rel="stylesheet" href="assets/style.css">
      <link rel="stylesheet" href="assets/header-footer.css">
      <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
   </head>
   <body>
      <!-- Header Start -->
      <header class="header">
         <div class="header-container">
            <div class="logo">
               <a href="../Home/index.php">Informatika<span>Hub</span></a>
            </div>
            <div class="nav-menu">
               <ul>
                  <li><a href="../Home/index.php">Home</a></li>
                  <li><a href="../Home/index.php#explore">Explore</a></li>
                  <li><a href="../Tutorial/course.php">Tutorials</a></li>
                  <li><a href="../Home/index.php#contact">Contact</a></li>
               </ul>
            </div>
         </div>
      </header>
      <!-- Header End -->
      
      <div class="wrapper">
         <div class="title">
            Login Form
         </div>
         <?php if(isset($error_message)): ?>
         <div style="background-color: #f8d7da; color: #721c24; padding: 10px; margin-bottom: 15px; border-radius: 5px; text-align: center;">
            <?php echo $error_message; ?>
         </div>
         <?php endif; ?>
		<form action="login.php" method="post">
			<div class="field">
				<input type="text" name="email" required>
				<label>Alamat Email</label>
		    </div>
		    <div class="field">
				<input type="password" name="password" required>
				<label>Password</label>
		    </div>
            <div class="content">
               <div class="checkbox">
                  <input type="checkbox" id="remember-me">
                  <label for="remember-me">Remember me</label>
               </div>
               <div class="pass-link">
                  <a href="#">Forgot password?</a>
               </div>
            </div>
            <div class="field">
               <input type="submit" value="Login">
            </div>
            <div class="signup-link">
               Not a member? <a href="signup.php">Signup now</a>
            </div>
         </form>
      </div>

      <!-- Footer Start -->
      <footer class="footer">
         <div class="footer-container">
            <div class="footer-content">
               <div class="footer-section">
                  <h2>Informatika<span style="color: #ff3333;">Hub</span></h2>
                  <p>Modern Web Learning Platform</p>
               </div>

               <div class="footer-section">
                  <h2>Link</h2>
                  <p><a href="../Home/index.php">Home</a></p>
                  <p><a href="../Home/index.php#explore">Explore</a></p>
                  <p><a href="../Tutorial/course.php">Tutorials</a></p>
                  <p><a href="../Home/index.php#contact">Contact</a></p>
               </div>

               <div class="footer-section">
                  <h2>Popular Topics</h2>
                  <p><a href="../Tutorial/course.php?topic=html">HTML</a></p>
                  <p><a href="../Tutorial/course.php?topic=css">CSS</a></p>
                  <p><a href="../Tutorial/course.php?topic=javascript">JavaScript</a></p>
                  <p><a href="../Tutorial/course.php?topic=react">React</a></p>
                  <p><a href="../Tutorial/course.php?topic=blockchain">Blockchain</a></p>
               </div>

               <div class="footer-section">
                  <h2>Contacts</h2>
                  <p>+62 123 456 789</p>
                  <p><a href="mailto:info@informatikahub.com">info@informatikahub.com</a></p>
                  <p>Jl. Pendidikan No. 123</p>
                  <p>Jakarta, Indonesia</p>
               </div>
            </div>

            <div class="footer-bottom">
               <div class="footer-social">
                  <a href="#"><i class="fab fa-facebook-f"></i></a>
                  <a href="#"><i class="fab fa-twitter"></i></a>
                  <a href="#"><i class="fab fa-instagram"></i></a>
               </div>
               <p>&copy; 2025 <a href="../Home/index.php">Informatika Hub</a>. All Rights Reserved</p>
            </div>
         </div>
      </footer>
      <!-- Footer End -->
   </body>
</html>
?>
