<?php
/**
 * Informatika Hub - Main Entry Point
 * 
 * This file redirects to the Home page and starts the session
 */

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Redirect to the Home page
header("Location: Home/index.php");
exit();
?>
