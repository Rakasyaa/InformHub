<?php
/**
 * Informatika Hub - Unified Database Setup
 * 
 * This script sets up the unified database for the Informatika Hub website,
 * combining the login, home, and tutorial sections.
 */

// Database configuration
$host = "localhost";
$user = "root";
$pass = "";
$db_name = "simple_login";

// Create connection
$conn = new mysqli($host, $user, $pass);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "<div style='font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px;'>";
echo "<h1>Informatika Hub - Database Setup</h1>";

// Check if database exists
$db_exists = $conn->query("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '$db_name'");

if ($db_exists->num_rows == 0) {
    // Create database
    if ($conn->query("CREATE DATABASE IF NOT EXISTS $db_name")) {
        echo "<p style='color: green;'>✓ Database '$db_name' created successfully.</p>";
    } else {
        echo "<p style='color: red;'>✗ Error creating database: " . $conn->error . "</p>";
        exit;
    }
} else {
    echo "<p>Database '$db_name' already exists.</p>";
}

// Select the database
$conn->select_db($db_name);

// Read and execute SQL file
$sql_file = file_get_contents('unified_database.sql');

// Split SQL commands by semicolon
$commands = explode(';', $sql_file);

$success_count = 0;
$error_count = 0;

echo "<h2>Executing SQL commands:</h2>";
echo "<ul>";

foreach ($commands as $command) {
    $command = trim($command);
    
    if (empty($command)) {
        continue;
    }
    
    // Execute command
    if ($conn->query($command)) {
        $success_count++;
    } else {
        $error_count++;
        echo "<li style='color: red;'>Error: " . $conn->error . "</li>";
    }
}

echo "</ul>";

// Show summary
echo "<h2>Summary:</h2>";
echo "<p>$success_count commands executed successfully.</p>";

if ($error_count > 0) {
    echo "<p style='color: red;'>$error_count errors occurred.</p>";
} else {
    echo "<p style='color: green;'>No errors occurred. Database setup completed successfully!</p>";
}

// Close connection
$conn->close();

echo "<div style='margin-top: 20px;'>";
echo "<a href='../index.php' style='background-color: #4CAF50; color: white; padding: 10px 15px; text-decoration: none; border-radius: 4px;'>Go to Home Page</a>";
echo "</div>";

echo "</div>";
?>
