-- Script untuk memperbaiki struktur database dan menambahkan kolom role

USE simple_login;

-- Cek apakah tabel users sudah ada
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Cek dan tambahkan kolom role jika belum ada
SET @check_role = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
                  WHERE TABLE_SCHEMA = 'simple_login' 
                  AND TABLE_NAME = 'users' 
                  AND COLUMN_NAME = 'role');

-- Jika kolom role belum ada, tambahkan
SET @alter_query = IF(@check_role = 0, 
                    'ALTER TABLE users ADD COLUMN role ENUM(\'user\', \'moderator\', \'admin\') NOT NULL DEFAULT \'user\'', 
                    'SELECT \'Kolom role sudah ada\' AS message');

PREPARE stmt FROM @alter_query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Pastikan user default ada dan memiliki role admin
INSERT IGNORE INTO users (username, email, password) 
VALUES ('user', 'user@gmail.com', '123');

-- Update user default menjadi admin
UPDATE users SET role = 'admin' WHERE email = 'user@gmail.com';

-- Tampilkan pesan sukses
SELECT 'Database berhasil diperbaiki. Kolom role sudah ditambahkan dan user admin sudah diatur.' AS Status;
