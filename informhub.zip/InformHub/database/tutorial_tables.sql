-- Tutorial Database Tables

-- Add user_roles to existing users table
ALTER TABLE users ADD COLUMN role ENUM('user', 'moderator', 'admin') NOT NULL DEFAULT 'user';

-- Update existing user to be admin
UPDATE users SET role = 'admin' WHERE email = 'user@gmail.com';

-- Create table for tutorial content
CREATE TABLE tutorial_content (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT,
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Create table for tutorial sections
CREATE TABLE tutorial_sections (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tutorial_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    section_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (tutorial_id) REFERENCES tutorial_content(id) ON DELETE CASCADE
);

-- Create table for code examples
CREATE TABLE code_examples (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tutorial_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    code TEXT NOT NULL,
    language VARCHAR(50) NOT NULL DEFAULT 'html',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (tutorial_id) REFERENCES tutorial_content(id) ON DELETE CASCADE
);

-- Create table for comments
CREATE TABLE comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tutorial_id INT NOT NULL,
    user_id INT NOT NULL,
    content TEXT NOT NULL,
    is_pinned BOOLEAN NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (tutorial_id) REFERENCES tutorial_content(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Insert sample data for HTML tutorial
INSERT INTO tutorial_content (category, title, description) VALUES 
('html', 'HTML Fundamentals', 'Learn the basics of HTML, the building blocks of web pages');

-- Get the ID of the inserted tutorial
SET @html_tutorial_id = LAST_INSERT_ID();

-- Insert sections for HTML tutorial
INSERT INTO tutorial_sections (tutorial_id, title, content, section_order) VALUES
(@html_tutorial_id, 'Introduction to HTML', '<p>HTML (HyperText Markup Language) is the standard markup language for creating web pages. It describes the structure of a web page and consists of a series of elements that tell the browser how to display the content.</p>', 1),
(@html_tutorial_id, 'HTML Elements', '<p>HTML elements are represented by tags. Tags are enclosed in angle brackets, and come in pairs with opening and closing tags.</p><p>Example: <code>&lt;h1&gt;This is a heading&lt;/h1&gt;</code></p>', 2),
(@html_tutorial_id, 'HTML Attributes', '<p>HTML attributes provide additional information about an element. They are always specified in the start tag and usually come in name/value pairs.</p><p>Example: <code>&lt;a href="https://www.example.com"&gt;Visit Example.com&lt;/a&gt;</code></p>', 3);

-- Insert code example for HTML tutorial
INSERT INTO code_examples (tutorial_id, title, description, code, language) VALUES
(@html_tutorial_id, 'Basic HTML Document', 'A simple HTML document structure', '<!DOCTYPE html>\n<html>\n<head>\n  <title>My First Web Page</title>\n</head>\n<body>\n  <h1>Welcome to My Web Page</h1>\n  <p>This is a paragraph.</p>\n</body>\n</html>', 'html');

-- Insert sample data for CSS tutorial
INSERT INTO tutorial_content (category, title, description) VALUES 
('css', 'CSS Styling', 'Learn how to style your HTML elements with CSS');

-- Get the ID of the inserted tutorial
SET @css_tutorial_id = LAST_INSERT_ID();

-- Insert sections for CSS tutorial
INSERT INTO tutorial_sections (tutorial_id, title, content, section_order) VALUES
(@css_tutorial_id, 'Introduction to CSS', '<p>CSS (Cascading Style Sheets) is used to style and layout web pages. It describes how HTML elements should be displayed.</p>', 1),
(@css_tutorial_id, 'CSS Selectors', '<p>CSS selectors are used to "find" (or select) the HTML elements you want to style. They can be element selectors, class selectors, or ID selectors.</p>', 2),
(@css_tutorial_id, 'CSS Box Model', '<p>The CSS box model is essentially a box that wraps around every HTML element. It consists of margins, borders, padding, and the actual content.</p>', 3);

-- Insert code example for CSS tutorial
INSERT INTO code_examples (tutorial_id, title, description, code, language) VALUES
(@css_tutorial_id, 'Basic CSS Styling', 'Simple CSS styling for a webpage', 'body {\n  font-family: Arial, sans-serif;\n  margin: 0;\n  padding: 20px;\n  background-color: #f0f0f0;\n}\n\nh1 {\n  color: #0066cc;\n  text-align: center;\n}\n\np {\n  line-height: 1.6;\n  margin-bottom: 15px;\n}', 'css');
