-- Unified Database for InformHub (Login, Home, and Tutorial)

-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS simple_login;

USE simple_login;

-- Create users table if it doesn't exist
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Check if role column exists, if not add it
SET @exist := (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
               WHERE TABLE_SCHEMA = 'simple_login' 
               AND TABLE_NAME = 'users' 
               AND COLUMN_NAME = 'role');

SET @query = IF(@exist = 0, 'ALTER TABLE users ADD COLUMN role ENUM(\'user\', \'moderator\', \'admin\') NOT NULL DEFAULT \'user\'', 'SELECT "Role column already exists" AS message');

PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Insert default admin user if not exists
INSERT INTO users (username, email, password) 
SELECT 'user', 'user@gmail.com', '123'
FROM dual
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'user@gmail.com');

-- Update the user to be admin if role column exists
SET @exist := (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
               WHERE TABLE_SCHEMA = 'simple_login' 
               AND TABLE_NAME = 'users' 
               AND COLUMN_NAME = 'role');

SET @query = IF(@exist > 0, 'UPDATE users SET role = \'admin\' WHERE email = \'user@gmail.com\'', 'SELECT "Role column does not exist yet" AS message');

PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Create table for user progress if it doesn't exist
CREATE TABLE IF NOT EXISTS user_progress (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    topic VARCHAR(50) NOT NULL,
    progress INT DEFAULT 0,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Create table for completed lessons if it doesn't exist
CREATE TABLE IF NOT EXISTS completed_lessons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    lesson_id VARCHAR(100) NOT NULL,
    completion_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Create table for tutorial content if it doesn't exist
CREATE TABLE IF NOT EXISTS tutorial_content (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT,
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Create table for tutorial sections if it doesn't exist
CREATE TABLE IF NOT EXISTS tutorial_sections (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tutorial_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    section_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (tutorial_id) REFERENCES tutorial_content(id) ON DELETE CASCADE
);

-- Create table for code examples if it doesn't exist
CREATE TABLE IF NOT EXISTS code_examples (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tutorial_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    code TEXT NOT NULL,
    language VARCHAR(50) NOT NULL DEFAULT 'html',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (tutorial_id) REFERENCES tutorial_content(id) ON DELETE CASCADE
);

-- Create table for comments if it doesn't exist
CREATE TABLE IF NOT EXISTS comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tutorial_id INT NOT NULL,
    user_id INT NOT NULL,
    content TEXT NOT NULL,
    is_pinned BOOLEAN NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (tutorial_id) REFERENCES tutorial_content(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Insert sample data for HTML tutorial if not exists
INSERT INTO tutorial_content (category, title, description) 
SELECT 'html', 'HTML Fundamentals', 'Learn the basics of HTML, the building blocks of web pages'
FROM dual
WHERE NOT EXISTS (SELECT 1 FROM tutorial_content WHERE category = 'html' AND title = 'HTML Fundamentals');

-- Get the ID of the HTML tutorial
SET @html_tutorial_id = (SELECT id FROM tutorial_content WHERE category = 'html' AND title = 'HTML Fundamentals' LIMIT 1);

-- Insert sections for HTML tutorial if not exists
INSERT INTO tutorial_sections (tutorial_id, title, content, section_order)
SELECT @html_tutorial_id, 'Introduction to HTML', '<p>HTML (HyperText Markup Language) is the standard markup language for creating web pages. It describes the structure of a web page and consists of a series of elements that tell the browser how to display the content.</p>', 1
FROM dual
WHERE NOT EXISTS (SELECT 1 FROM tutorial_sections WHERE tutorial_id = @html_tutorial_id AND title = 'Introduction to HTML');

INSERT INTO tutorial_sections (tutorial_id, title, content, section_order)
SELECT @html_tutorial_id, 'HTML Elements', '<p>HTML elements are represented by tags. Tags are enclosed in angle brackets, and come in pairs with opening and closing tags.</p><p>Example: <code>&lt;h1&gt;This is a heading&lt;/h1&gt;</code></p>', 2
FROM dual
WHERE NOT EXISTS (SELECT 1 FROM tutorial_sections WHERE tutorial_id = @html_tutorial_id AND title = 'HTML Elements');

INSERT INTO tutorial_sections (tutorial_id, title, content, section_order)
SELECT @html_tutorial_id, 'HTML Attributes', '<p>HTML attributes provide additional information about an element. They are always specified in the start tag and usually come in name/value pairs.</p><p>Example: <code>&lt;a href="https://www.example.com"&gt;Visit Example.com&lt;/a&gt;</code></p>', 3
FROM dual
WHERE NOT EXISTS (SELECT 1 FROM tutorial_sections WHERE tutorial_id = @html_tutorial_id AND title = 'HTML Attributes');

-- Insert code example for HTML tutorial if not exists
INSERT INTO code_examples (tutorial_id, title, description, code, language)
SELECT @html_tutorial_id, 'Basic HTML Document', 'A simple HTML document structure', '<!DOCTYPE html>\n<html>\n<head>\n  <title>My First Web Page</title>\n</head>\n<body>\n  <h1>Welcome to My Web Page</h1>\n  <p>This is a paragraph.</p>\n</body>\n</html>', 'html'
FROM dual
WHERE NOT EXISTS (SELECT 1 FROM code_examples WHERE tutorial_id = @html_tutorial_id AND title = 'Basic HTML Document');

-- Insert sample data for CSS tutorial if not exists
INSERT INTO tutorial_content (category, title, description)
SELECT 'css', 'CSS Styling', 'Learn how to style your HTML elements with CSS'
FROM dual
WHERE NOT EXISTS (SELECT 1 FROM tutorial_content WHERE category = 'css' AND title = 'CSS Styling');

-- Get the ID of the CSS tutorial
SET @css_tutorial_id = (SELECT id FROM tutorial_content WHERE category = 'css' AND title = 'CSS Styling' LIMIT 1);

-- Insert sections for CSS tutorial if not exists
INSERT INTO tutorial_sections (tutorial_id, title, content, section_order)
SELECT @css_tutorial_id, 'Introduction to CSS', '<p>CSS (Cascading Style Sheets) is used to style and layout web pages. It describes how HTML elements should be displayed.</p>', 1
FROM dual
WHERE NOT EXISTS (SELECT 1 FROM tutorial_sections WHERE tutorial_id = @css_tutorial_id AND title = 'Introduction to CSS');

INSERT INTO tutorial_sections (tutorial_id, title, content, section_order)
SELECT @css_tutorial_id, 'CSS Selectors', '<p>CSS selectors are used to "find" (or select) the HTML elements you want to style. They can be element selectors, class selectors, or ID selectors.</p>', 2
FROM dual
WHERE NOT EXISTS (SELECT 1 FROM tutorial_sections WHERE tutorial_id = @css_tutorial_id AND title = 'CSS Selectors');

INSERT INTO tutorial_sections (tutorial_id, title, content, section_order)
SELECT @css_tutorial_id, 'CSS Box Model', '<p>The CSS box model is essentially a box that wraps around every HTML element. It consists of margins, borders, padding, and the actual content.</p>', 3
FROM dual
WHERE NOT EXISTS (SELECT 1 FROM tutorial_sections WHERE tutorial_id = @css_tutorial_id AND title = 'CSS Box Model');

-- Insert code example for CSS tutorial if not exists
INSERT INTO code_examples (tutorial_id, title, description, code, language)
SELECT @css_tutorial_id, 'Basic CSS Styling', 'Simple CSS styling for a webpage', 'body {\n  font-family: Arial, sans-serif;\n  margin: 0;\n  padding: 20px;\n  background-color: #f0f0f0;\n}\n\nh1 {\n  color: #0066cc;\n  text-align: center;\n}\n\np {\n  line-height: 1.6;\n  margin-bottom: 15px;\n}', 'css'
FROM dual
WHERE NOT EXISTS (SELECT 1 FROM code_examples WHERE tutorial_id = @css_tutorial_id AND title = 'Basic CSS Styling');
